# Software Factory SVG Asset Pack

Original vector assets for the Software Factory UI mockups.

## Contents
- `logos/`: product mark, horizontal wordmark, monochrome and white variants.
- `icons/navigation/`: primary application navigation.
- `icons/workspace/`: repository intelligence, code review and graph workspace.
- `icons/agents/`: agent-role icons.
- `icons/status/`: success, warning, error, running and pending states.
- `icons/providers/`: generic provider, local model and routing icons.

## Design conventions
- Icons use a 24x24 viewBox, rounded strokes and a 1.8 stroke width.
- Default stroke is `#243B73`; override with CSS `color`/`stroke` if desired.
- Brand palette: navy `#14264D`, blue `#2478E8`, violet `#7467FF`,
  light blue `#BFCBFF`.
- All marks are original generic Software Factory branding; provider icons
  are generic and are not official third-party trademarks.

## Usage
Use an SVG as an image:
`<img src="/assets/icons/navigation/dashboard.svg" alt="" />`

Or inline the SVG markup to allow CSS styling of stroke and fill.
